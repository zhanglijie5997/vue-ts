const USER_MSG = 'USER_MSG';
const PEOPLE_MSG = 'PEOPLE_MSG';
const USER_TOKEN = 'USER_TOKEN';
const CHOIC_PAGE = 'CHOIC_PAGE'
export default {
    USER_MSG,
    PEOPLE_MSG,
    USER_TOKEN,
    CHOIC_PAGE
}