import Http from '../http';
import log from '../log';
const HttpCreate = new Http();
export const index = async () => {
       const data = await HttpCreate.createClient('/trade/data/getAllNewest.o?&categoryId=6', {
            methods: 'post'
        })
        .then((res: any) => {
            if (res.statusCode === 0) {
                // log.log(res.result)
                return res['result'];
            }
        })
        return data;
}