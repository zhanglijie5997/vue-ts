export default {
    getData: '/mock/5c09ca373601b6783189502a/example/mock', // 随机数据 来自 easy mock
}